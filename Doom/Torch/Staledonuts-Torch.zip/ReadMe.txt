 
This was created by Staledonuts no credits needed although always appreciated.

Mainly made as a Doom Sprite with the doom palette.
